
-- Run this with: psql -U <user> -d procurement_db -f load.sql
-- It will create schema and load data.
\i procurement_schema.sql
\i procurement_data.sql
