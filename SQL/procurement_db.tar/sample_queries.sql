
-- 🔎 Sample analytical queries for your portfolio

-- 1) Spesa totale per dipartimento (Top 10)
SELECT d.name AS department, ROUND(SUM(po.total_amount),2) AS total_spend
FROM purchase_orders po
JOIN departments d ON d.department_id = po.department_id
GROUP BY d.name
ORDER BY total_spend DESC
LIMIT 10;

-- 2) Spesa mensile totale negli ultimi 12 mesi
SELECT DATE_TRUNC('month', order_date) AS month, ROUND(SUM(total_amount),2) AS total_spend
FROM purchase_orders
WHERE order_date >= (CURRENT_DATE - INTERVAL '12 months')
GROUP BY 1
ORDER BY 1;

-- 3) Fornitori top per fatturato e rating >= 4.0
SELECT s.name AS supplier, s.country, s.rating, ROUND(SUM(po.total_amount),2) AS total_spend
FROM purchase_orders po
JOIN suppliers s ON s.supplier_id = po.supplier_id
WHERE s.rating >= 4.0
GROUP BY s.name, s.country, s.rating
ORDER BY total_spend DESC;

-- 4) Categorie più acquistate (per valore)
SELECT i.category, ROUND(SUM(od.subtotal),2) AS category_spend
FROM order_details od
JOIN items i ON i.item_id = od.item_id
GROUP BY i.category
ORDER BY category_spend DESC;

-- 5) Prezzo medio praticato per item vs catalogo
SELECT i.item_id, i.description,
       ROUND(AVG(od.unit_price),2) AS avg_unit_price,
       i.unit_price AS catalog_price,
       ROUND(AVG(od.unit_price) - i.unit_price, 2) AS delta_vs_catalog
FROM order_details od
JOIN items i ON i.item_id = od.item_id
GROUP BY i.item_id, i.description, i.unit_price
ORDER BY i.item_id
LIMIT 50;
