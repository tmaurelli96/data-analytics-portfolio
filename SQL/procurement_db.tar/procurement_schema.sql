
-- Schema for procurement_db
CREATE SCHEMA IF NOT EXISTS public;

DROP TABLE IF EXISTS order_details;
DROP TABLE IF EXISTS purchase_orders;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS departments;

CREATE TABLE departments (
    department_id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE suppliers (
    supplier_id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    country TEXT NOT NULL,
    rating NUMERIC(2,1) CHECK (rating >= 1 AND rating <= 5),
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE items (
    item_id SERIAL PRIMARY KEY,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    unit_price NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0)
);

CREATE TABLE purchase_orders (
    order_id SERIAL PRIMARY KEY,
    department_id INT NOT NULL REFERENCES departments(department_id),
    supplier_id INT NOT NULL REFERENCES suppliers(supplier_id),
    order_date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('approved','pending','rejected','received')),
    total_amount NUMERIC(12,2) NOT NULL DEFAULT 0
);

CREATE TABLE order_details (
    order_id INT NOT NULL REFERENCES purchase_orders(order_id) ON DELETE CASCADE,
    item_id INT NOT NULL REFERENCES items(item_id),
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0),
    subtotal NUMERIC(12,2) NOT NULL,
    PRIMARY KEY (order_id, item_id)
);

-- Helpful indexes
CREATE INDEX idx_po_date ON purchase_orders(order_date);
CREATE INDEX idx_po_supplier ON purchase_orders(supplier_id);
CREATE INDEX idx_item_category ON items(category);
