
# Procurement DB (portfolio)

Questo pacchetto contiene uno **schema PostgreSQL** + **dati simulati** per un caso d'uso di *procurement* (appalti/acquisti).
Ti permette di mostrare l'intero flusso: SQL → analisi → esportazione → Power BI.

## 📦 Contenuto
- `procurement_schema.sql`: definizione tabelle, chiavi, indici
- `procurement_data.sql`: INSERT dei dati (~220 ordini, 50 item, 25 fornitori, 10 dipartimenti)
- `load.sql`: script che richiama schema + dati
- `sample_queries.sql`: query di analisi pronte da usare

## ⚙️ Requisiti
- PostgreSQL 13+ (qualsiasi versione recente va bene)
- Utente con permessi di creazione tabelle

## 🧪 Come creare il DB e caricare i dati
```bash
createdb procurement_db
psql -U <utente> -d procurement_db -f load.sql
```

> Sostituisci `<utente>` con il tuo utente PostgreSQL (es. `postgres`).

## 🔁 (Opzionale) Creare un **backup .tar** con `pg_dump`
Se vuoi un file in formato `.tar` compatibile con `pg_restore` per il portfolio:

```bash
pg_dump -U <utente> -F t -f procurement_db.tar procurement_db
```

Potrai poi ripristinarlo su un'altra macchina con:
```bash
createdb procurement_db
pg_restore -U <utente> -d procurement_db procurement_db.tar
```

## 📊 Idee di analisi (Power BI / SQL)
- Spesa per dipartimento, fornitore, categoria
- Trend mensile e stagionalità
- Confronto prezzo medio praticato vs listino
- KPI: lead time (se aggiungi colonne data consegna), % ordini approvati, ecc.

Buon lavoro sul tuo portfolio! 🎯
